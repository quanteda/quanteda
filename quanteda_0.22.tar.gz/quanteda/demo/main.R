# The main demo file for quanteda
# this can be called with demo(main, package="quanteda")

corp <- corpus(uk2010immig)

# further demonstration... 
