library(testthat) 
library(quanteda)
test_package("quanteda") 
