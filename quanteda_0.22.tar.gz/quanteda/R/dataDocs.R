#' @name inaugCorpus
#' @title Corpus of US presidential inaugaration speeches
#' @description Corpus of US presidential inaugaration speeches
#' @docType data
NULL

#' @name inaugTexts
#' @title Texts of US presidential inaugaration speeches
#' @description Character vector of US presidential inaugaration speeches
#' @docType data
NULL

#' @name uk2010immig
#' @description Character vector of immigration-related sections from UK 2010 political party manifestos.
#' @title Texts of UK 2010 manifestos on immigration
#' @docType data
NULL

