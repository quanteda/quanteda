#library(gWidgets)
#options(guiToolkit="RGtk2")
#window <- gwindow("Hello World!", visible=FALSE)
#visible(window) <- TRUE
# TEST