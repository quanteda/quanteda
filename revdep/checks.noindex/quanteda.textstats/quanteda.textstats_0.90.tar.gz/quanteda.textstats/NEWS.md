# quanteda.textstats 0.90

First version, split from **quanteda** 2.2.  This is a transitional version
designed to get the package on CRAN, so that we can shift existing reverse
dependencies to the new package, before we update **quanteda** with a new
version without the `textstat_*()` functions.
