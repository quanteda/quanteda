unused_dots <- quanteda:::unused_dots

friendly_class_undefined_message <- quanteda:::friendly_class_undefined_message

message_error <- quanteda:::message_error

removals_regex <- quanteda:::removals_regex

pad_dfm <- quanteda:::pad_dfm

get_cache <- quanteda:::get_cache

set_cache <- quanteda:::set_cache

clear_cache <- quanteda:::clear_cache

hash_object <- quanteda:::clear_cache
