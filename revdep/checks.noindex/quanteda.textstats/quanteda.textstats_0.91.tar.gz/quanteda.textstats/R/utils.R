unused_dots <- quanteda:::unused_dots

friendly_class_undefined_message <- quanteda:::friendly_class_undefined_message

message_error <- quanteda:::message_error

removals_regex <- quanteda:::removals_regex

pad_dfm <- quanteda:::pad_dfm
