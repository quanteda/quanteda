library(testthat)
library(rainette)

test_check("rainette")
