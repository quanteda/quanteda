## usethis namespace: start
#' @useDynLib rainette
## usethis namespace: end
NULL

## usethis namespace: start
#' @importFrom Rcpp sourceCpp evalCpp
## usethis namespace: end
NULL
