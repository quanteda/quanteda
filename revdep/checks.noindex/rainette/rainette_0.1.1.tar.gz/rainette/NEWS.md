# rainette 0.1.1

* Compatibility with dplyr 1.0
* Fix bug in p threshold in rainette_stats()


# rainette 0.1

* First version