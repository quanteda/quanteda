library("testthat")
library("textstem")

test_check("textstem")