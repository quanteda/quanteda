lg$set_threshold(old_threshold)
