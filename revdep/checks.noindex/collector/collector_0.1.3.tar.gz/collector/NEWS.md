# collector 0.1.3

* Remove timer from interview slides.
* Correct `check_readability()` column errors.
* Update for tidyr 1.0 changes.

# collector 0.1.2

* Fix namespace requirement for xaringan.
* Do not run pandoc tests when pandoc is not available.

# collector 0.1.1

* Documentation improvements.
* Add system dependency on pandoc.
* Remove inadvertent dependency on R 3.5.0 `tempdir()` syntax.

# collector 0.1.0

* Initial release.
