library(testthat)
library(collector)

test_check("collector")
