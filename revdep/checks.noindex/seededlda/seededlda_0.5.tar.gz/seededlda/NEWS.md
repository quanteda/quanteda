# Change in v0.5

* Implement original LDA estimator using the LDAGibbs++ library
