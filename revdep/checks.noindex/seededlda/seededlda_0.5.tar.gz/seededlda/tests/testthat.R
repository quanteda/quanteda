require(seededlda)
require(testthat)
test_check("seededlda")
