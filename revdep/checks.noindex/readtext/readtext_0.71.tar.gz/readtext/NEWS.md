readtext 0.7.1
==============

*  Added `readtext_options()`, fixes #123.


readtext 0.7.0
==============

*  Move to **xml2** instead of the older **XML** package.  
*  Change options settings so that package can be used without loading it first.


readtext 0.5.0
==============

First CRAN release.
