.onAttach <- function(...) {
    # set user options
    readtext_options(initialize = TRUE)
}
