require(testthat)
test_check("newsmap")
