# clustRcompaR 0.2.0

* Added a `NEWS.md` file to track changes to the package.
* Made updates in response to updates in the quanteda `dfm()` function
* Improved aesethetics and functionality of the plot
* Fixed defaults for the `compare()` function so that which clusters and which profiles do not need to be manually entered
* Added a `README.rmd` file with examples from the built-in inaugural addresses dataset from the quanteda package
* Made minor changes to the vignette
