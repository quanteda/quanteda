library(testthat)
library(clustRcompaR)
library(quanteda)

test_check("clustRcompaR")

