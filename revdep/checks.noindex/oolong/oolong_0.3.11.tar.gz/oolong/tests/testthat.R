library(testthat)
library(oolong)

test_check("oolong")
