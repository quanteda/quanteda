
library("testthat")
library("sentometrics")

test_check("sentometrics")

