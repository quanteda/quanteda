#devtools::build_vignettes()
#devtools::install(build_vignettes = TRUE)

#library(corpustools)

#vignette('corpustools')
#vignette(package='corpustools')

