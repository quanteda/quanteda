## Let roxygen2 add imports to namespace

#' @import Matrix
#' @import data.table
#' @importFrom Rcpp evalCpp
#' @importFrom R6 R6Class
#' @useDynLib corpustools
NULL
