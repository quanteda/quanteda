.onAttach <- function(libname, pkgname) {
    packageStartupMessage("preText: Diagnostics to Assess the Effects of Text Preprocessing Decisions
Version 0.6.3 created on 2018-01-12.
copyright (c) 2017, Matthew J. Denny, Penn State University
                    Arthur Spirling, NYU
Type vignette('getting_started_with_preText') to get started.
Development website: https://github.com/matthewjdenny/preText")
}
