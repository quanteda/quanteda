library(testthat)
library(preText)

test_check("preText")
