context("Checking q_tdm")

test_that("q_tdm ...",{


})

