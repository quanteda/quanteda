context("Checking q_dtm")

test_that("q_dtm ...",{


})

