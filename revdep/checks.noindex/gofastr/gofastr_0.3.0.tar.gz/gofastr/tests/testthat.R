library("testthat")
library("gofastr")

test_check("gofastr")