library(testthat)
library(politeness)

test_check("politeness")
