library(testthat)
library(rJST)

test_check("rJST")
