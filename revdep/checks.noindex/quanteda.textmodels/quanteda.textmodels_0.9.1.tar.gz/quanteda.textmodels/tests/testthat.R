library("testthat")
library("quanteda.textmodels")

test_check("quanteda.textmodels")
