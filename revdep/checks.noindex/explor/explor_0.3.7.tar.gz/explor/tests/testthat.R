library(testthat)
library(explor)

test_check("explor")
