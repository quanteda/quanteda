library(testthat)
library(keyATM)

test_check("keyATM")
