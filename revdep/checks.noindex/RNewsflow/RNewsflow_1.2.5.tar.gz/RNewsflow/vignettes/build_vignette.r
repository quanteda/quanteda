#devtools::build_vignettes()
#devtools::install(build_vignettes = TRUE)

#library(RNewsflow)

#vignette('RNewsflow')
#vignette(package='RNewsflow')

