library(testthat)
library(doc2concrete)

test_check("doc2concrete")
