# quanteda.textplots 0.90

New version split from quanteda 2.1.2, moving the `textplot_*()` functions to a separate package as part of a modularisation of the quanteda family of packages.
