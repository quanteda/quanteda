.onAttach <- function(libname, pkgname) {
    packageStartupMessage("phrasemachine: Simple Phrase Extraction
Version 1.1.2 created on 2017-05-29.
copyright (c) 2016, Matthew J. Denny, Abram Handler, Brendan O'Connor.
Type help('phrasemachine') or
vignette('getting_started_with_phrasemachine') to get started.
Development website: https://github.com/slanglab/phrasemachine")
}
