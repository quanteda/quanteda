library(testthat)
library(phrasemachine)

test_check("phrasemachine")
